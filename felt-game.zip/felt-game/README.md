# Felt practice casino: server + admin panel
Practice coins only. No real money, payments or payouts.

## Run
    node server.js            (Node 18+, no npm install needed)
Game:  http://localhost:3000     Admin panel: http://localhost:3000/admin
Set your own admin login:  ADMIN_USER=you ADMIN_PASS=strongpass node server.js
Data is saved in data.json next to server.js.

## What you can see in /admin
Users (balance, deposits, withdrawals, wagered, won, plays, logins, joined, last seen, IP, device),
withdrawal requests (Approve / Reject; reject refunds the coins), all transactions, all game plays.

## Put it online
Deploy this folder on Render, Railway or any VPS (start command: node server.js).
Use HTTPS. Tell users in a privacy policy that username, activity, IP and device info are stored.

## APK
In public/index.html set  const API='https://your-server.com'  then build the APK
(PWABuilder or Capacitor, see chat). If the APK loads from your server URL you can leave API='' .

## Game fairness
All game results (dice, coin, roulette, slots, crash, blackjack, mines) are now decided on the server,
so players cannot change a result from the app. The app only shows the animation.

## New features
Leaderboard (top players by balance and biggest wins), levels with XP, and 9 achievements.
